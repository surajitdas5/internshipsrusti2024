package com.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.model.Doctor;
import com.medicare.model.Review;
import com.medicare.repository.ReviewRepository;

@Service
public class ReviewService {
	@Autowired
	ReviewRepository reviewRepo;
	
	public void addReview(Review review) {
		reviewRepo.save(review);
	}
	
	public List<Review> doctorReviews(Doctor docotr){
		return reviewRepo.findByDoctor(docotr);
	}
}
