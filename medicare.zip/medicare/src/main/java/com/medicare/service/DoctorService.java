package com.medicare.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.medicare.model.Doctor;
import com.medicare.model.Patient;
import com.medicare.repository.DoctorRepository;

@Service
public class DoctorService {
	@Autowired
	DoctorRepository docRepo;
	
	public boolean createDocotr(Doctor doctor, MultipartFile image, String uploadTo) {
		try {
			String fileName = uploadImage(image, uploadTo);
			if( fileName!= null) {
				doctor.setImageUrl(fileName);
				docRepo.save(doctor);
				return true;
			} else {
				return false;
			}			
		} catch (Exception e) {
			System.out.println("Accout Creation Error: "+e);
			return false;
		}
	}
	
	public String uploadImage(MultipartFile file, String uploadTo) {
		try {
			String fileName = UUID.randomUUID().toString()+"_"+file.getOriginalFilename();
			Path filePath = Paths.get(uploadTo, fileName);
			Files.createDirectories(filePath.getParent());
			Files.write(filePath, file.getBytes());
			return fileName;	
		} catch(Exception e) {
			System.out.println("File Upload Error: "+e);
			return null;
		}
	}
	
	public Doctor getDoctorByEmail(String email) {
		return docRepo.findByEmail(email);
	}
	
	public List<Doctor> getAllDocotrs(){
		return docRepo.findAll();
	}
	
	public Doctor getDoctorById(long id) {
		return docRepo.findById(id).orElse(null);
	}
	
}
