package com.medicare.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.model.Appointment;
import com.medicare.model.Doctor;
import com.medicare.model.Patient;
import com.medicare.repository.AppointmentRepository;

@Service
public class AppointmentService {
	@Autowired
	AppointmentRepository appRepo;
	
	public boolean addAppointment(Appointment appointment) {
		try {
			appRepo.save(appointment);
			return true;
		} catch (Exception e) {
			System.out.println("Appointment Error: "+e);
			return false;
		}
	}
	
	public List<Appointment> getPatientAppointments(Patient patient){
		return appRepo.findByPatient(patient);
	}
	
	public void deleteAppointment(long id) {
		appRepo.deleteById(id);
	}
	
	public List<Appointment> getDoctorAppointments(Doctor docotr, String date){
		return appRepo.findDoctorAppointments(docotr, date);
	}
}
