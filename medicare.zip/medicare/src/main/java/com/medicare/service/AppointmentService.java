package com.medicare.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.medicare.model.Appointment;
import com.medicare.repository.AppointmentRepository;

@Service
public class AppointmentService {
	@Autowired
	AppointmentRepository appRepo;
	
	public boolean addAppointment(Appointment appointment) {
		try {
			appRepo.save(appointment);
			return true;
		} catch (Exception e) {
			System.out.println("Appointment Error: "+e);
			return false;
		}
	}
}
