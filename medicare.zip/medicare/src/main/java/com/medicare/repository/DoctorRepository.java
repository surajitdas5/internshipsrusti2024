package com.medicare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.medicare.model.Doctor;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Long> {
	Doctor findByEmail(String email);
	
	@Query("SELECT d FROM Doctor d WHERE d.name LIKE %:name% AND d.specialization LIKE %:specialization% AND d.chamberAddress LIKE %:address%" )
	List<Doctor> searchDoctor(
			@Param("name") String name, 
			@Param("specialization") String specialization,
			@Param("address") String address
			);
}
