package com.medicare.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.medicare.model.Appointment;
import com.medicare.model.Doctor;
import com.medicare.model.Patient;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
	List<Appointment> findByPatient(Patient patient);
	
	@Query("SELECT a from Appointment a WHERE a.doctor= :doctor AND a.appointmentDate= :date")
	List<Appointment> findDoctorAppointments(@Param("doctor") Doctor doctor, @Param("date") String date);
}
