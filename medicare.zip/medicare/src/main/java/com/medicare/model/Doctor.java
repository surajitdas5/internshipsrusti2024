package com.medicare.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="doctors")
public class Doctor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	private String gender;
	private String specialization;
	private String qualification;
	@Column(name="chamber_address")
	private String chamberAddress;
	@Column(name="visiting_days")
	private String visitingDays;
	@Column(name="visiting_hours")
	private String visitingHours;
	private double fees;
	private String mobile;
	@Column(unique = true)
	private String email;
	private String password;
	@Column(name="image_url")
	private String imageUrl;
	@OneToMany(mappedBy = "doctor")
	private List<Appointment> appointment;
	@OneToMany(mappedBy = "doctor")
	private List<Review> review;
	
	
	public List<Review> getReview() {
		return review;
	}
	public void setReview(List<Review> review) {
		this.review = review;
	}
	public List<Appointment> getAppointment() {
		return appointment;
	}
	public void setAppointment(List<Appointment> appointment) {
		this.appointment = appointment;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getChamberAddress() {
		return chamberAddress;
	}
	public void setChamberAddress(String chamberAddress) {
		this.chamberAddress = chamberAddress;
	}
	public String getVisitingDays() {
		return visitingDays;
	}
	public void setVisitingDays(String visitingDays) {
		this.visitingDays = visitingDays;
	}
	public String getVisitingHours() {
		return visitingHours;
	}
	public void setVisitingHours(String visiitngHours) {
		this.visitingHours = visiitngHours;
	}
	public double getFees() {
		return fees;
	}
	public void setFees(double fees) {
		this.fees = fees;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	@Override
	public String toString() {
		return "Doctor [name=" + name + ", gender=" + gender + ", specialization=" + specialization + ", qualification="
				+ qualification + ", chamberAddress=" + chamberAddress + ", visitingDays=" + visitingDays
				+ ", visiitngHours=" + visitingHours + ", fees=" + fees + ", mobile=" + mobile + ", email=" + email
				+ ", password=" + password + ", imageUrl=" + imageUrl + "]";
	}
	public Doctor(String name, String gender, String specialization, String qualification, String chamberAddress,
			String visitingDays, String visiitngHours, double fees, String mobile, String email, String password,
			String imageUrl) {
		super();
		this.name = name;
		this.gender = gender;
		this.specialization = specialization;
		this.qualification = qualification;
		this.chamberAddress = chamberAddress;
		this.visitingDays = visitingDays;
		this.visitingHours = visiitngHours;
		this.fees = fees;
		this.mobile = mobile;
		this.email = email;
		this.password = password;
		this.imageUrl = imageUrl;
	}
	public Doctor() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
