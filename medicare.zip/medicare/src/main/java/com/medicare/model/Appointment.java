package com.medicare.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="appointments")
public class Appointment {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String appointmentDate;
	private String purpose;
	@ManyToOne()
	@JoinColumn(name = "doctor_id", nullable = false)
	private Doctor doctor;
	@ManyToOne()
	@JoinColumn(name = "patient_id", nullable = false)
	private Patient patient;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getPurpose() {
		return purpose;
	}
	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public Patient getPatient() {
		return patient;
	}
	public void setPatient(Patient patient) {
		this.patient = patient;
	}
	@Override
	public String toString() {
		return "Appointment [id=" + id + ", appointmentDate=" + appointmentDate + ", purpose=" + purpose + ", doctor="
				+ doctor + ", patient=" + patient + "]";
	}
	public Appointment(String appointmentDate, String purpose, Doctor doctor, Patient patient) {
		super();
		this.appointmentDate = appointmentDate;
		this.purpose = purpose;
		this.doctor = doctor;
		this.patient = patient;
	}
	public Appointment() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
