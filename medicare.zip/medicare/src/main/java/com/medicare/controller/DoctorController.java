package com.medicare.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.medicare.model.Appointment;
import com.medicare.model.Doctor;
import com.medicare.service.AppointmentService;
import com.medicare.service.DoctorService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/doctor")
public class DoctorController {
	
	@Autowired
	DoctorService docService;
	
	@Autowired
	AppointmentService appService;
	
	@GetMapping("/appointments")
	public String allAppointments(HttpSession session, Model model) {
		String email = (String) session.getAttribute("email");
		Doctor doctor = docService.getDoctorByEmail(email);
		String today = LocalDate.now().toString();
		
		List<Appointment> appointments = appService.getDoctorAppointments(doctor, today);
		model.addAttribute("appointments", appointments);
		
		return "doctor/appointment";
	}
	
	@PostMapping("/appointment-search")
	public String searchAppointment(@RequestParam("date") String date, HttpSession session, Model model) {
		String email = (String) session.getAttribute("email");
		Doctor doctor = docService.getDoctorByEmail(email);
		
		List<Appointment> appointments = appService.getDoctorAppointments(doctor, date);
		model.addAttribute("appointments", appointments);
		
		return "doctor/appointment";
	}
	
	@GetMapping("/profile")
	public String doctorProfile(HttpSession session, Model model) {
		String email = (String) session.getAttribute("email");
		Doctor doctor = docService.getDoctorByEmail(email);
		model.addAttribute("doctor", doctor);
		return "doctor/profile";
	}
	
	@GetMapping("/updateProfileForm")
	public String updateProfileForm(HttpSession session, Model model) {
		String email = (String) session.getAttribute("email");
		Doctor doctor = docService.getDoctorByEmail(email);
		model.addAttribute("doctor", doctor);
		return "doctor/update-profile";
	}
	
	@PostMapping("/updateProfile")
	public String updateProfile(@ModelAttribute("doctor") Doctor doctor) {
		docService.updateDoctor(doctor);
		return "redirect:/doctor/profile";
	}
	
	@PostMapping("/imageUpdate")
	public String updateImage(
			@RequestParam("id") long id,
			@RequestParam("image") MultipartFile image
			) {
		Doctor oldDoctor = docService.getDoctorById(id);
		String uploadTo = "uploads";
		docService.imageUpdate(oldDoctor, image, uploadTo);
		return "redirect:/doctor/profile";
	}
}
