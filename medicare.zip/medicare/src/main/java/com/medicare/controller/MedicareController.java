package com.medicare.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.medicare.model.Doctor;
import com.medicare.model.Patient;
import com.medicare.service.DoctorService;
import com.medicare.service.PatientService;

import jakarta.servlet.http.HttpSession;

@Controller
public class MedicareController {
	
	@Autowired
	PatientService patientService;
	
	@Autowired
	DoctorService docService;

	@GetMapping("/")
	public String homePage() {
		return "index";
	}

	@GetMapping("/about")
	public String about() {
		return "about";
	}
	@GetMapping("/signup-form")
	public String signUpForm(Model model) {
		Patient patient=new Patient();
		model.addAttribute("patient",patient);
		return "signup";
		}
	
	@PostMapping("/signup")
	public String signUp(@ModelAttribute Patient patient, RedirectAttributes reda) {
	System.out.println(patient);
	boolean res = patientService.createPatient(patient);
	if(res) {
		System.out.println("Patient Created");
		reda.addFlashAttribute("message", "Account created successfully");
	} else {
		System.out.println("Err");
		reda.addFlashAttribute("message", "Something went wrong. Try with a different email.");
	}
	return "redirect:/signup-form";
	}
	
	@GetMapping("/signin-form")
	public String signInForm() {
		return "signin";
		}
	
	@PostMapping("/signin")
	public String signIn( 
			@RequestParam("email")String e,
			@RequestParam("password")String p,
			Model model,
			HttpSession session
			) {
		System.out.println("Form Submitted");
		System.out.println(e+""+p);
		Patient patient = patientService.getPatientByEmail(e);
		System.out.println(p);
		if(patient != null) {
			if(patient.getPassword().equals(p)) {
				System.out.println("Login Successfull");
				session.setAttribute("email", patient.getEmail());
				session.setAttribute("name", patient.getName());
				return "redirect:/";
			} else {
				model.addAttribute("message", "Invalid Password");
			}
		} else {
			model.addAttribute("message", "Invalid Email or Password");
		}
		return "signin";
	}
	
	@GetMapping("/doctor/signin-form")
	public String docSignInForm() {
		return "doctor/signin";
	}
	
	@PostMapping("/doctor/signin")
	public String docSignIn( 
			@RequestParam("email")String e,
			@RequestParam("password")String p,
			Model model,
			HttpSession session
			) {
		Doctor doctor = docService.getDoctorByEmail(e);
		System.out.println(p);
		if(doctor != null) {
			if(doctor.getPassword().equals(p)) {
				System.out.println("Login Successfull");
				session.setAttribute("email", doctor.getEmail());
				session.setAttribute("name", doctor.getName());
				// TODO
				return "doctor/appointment";
			} else {
				model.addAttribute("message", "Invalid Password");
			}
		} else {
			model.addAttribute("message", "Invalid Email or Password");
		}
		return "doctor/signin";
	}
	
	@GetMapping("/doctor/signup-form")
	public String docSignUpForm(Model model) {
		Doctor doctor = new Doctor();
		model.addAttribute("doctor", doctor);
		return "doctor/signup";
	}
	
	@PostMapping("/doctor/signup")
	public String docSignUp(
			@ModelAttribute("docotr") Doctor doctor,
			@RequestParam("profileImage") MultipartFile profileImage,
			RedirectAttributes redirectAttr
			) {
		String uploadTo = "uploads";
		boolean response = docService.createDocotr(doctor, profileImage, uploadTo);
		if(response) {
			redirectAttr.addFlashAttribute("message", "Account is created");
		} else {
			redirectAttr.addFlashAttribute("message", "Something went wrong. Try with a different mail");
		}
		return "redirect:/doctor/signup-form";
	}
	
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	

	@GetMapping("/learn")
	public String learn(Model model) {
		String name = "Ram Sharma";
		int age = 20;
		double salary = 50000.00;
		int nums[] = {1, 4, 5, 2, 9};
		String foods[] = {"tea", "coffee", "milk"};
		Employee e1 = new Employee(101, "Sam", 800000);
		Employee e2 = new Employee(102, "Hari", 450000);
		Employee e3 = new Employee(103, "Sita", 900000);
		Employee emps[] = {e1, e2, e3};
		int number = 101;

		model.addAttribute("username", name);
		model.addAttribute("age", age);
		model.addAttribute("salary", salary);
		model.addAttribute("nums", nums);
		model.addAttribute("foods", foods);
		model.addAttribute("emps", emps);
		model.addAttribute("number", number);
		return "learn";
	}
}

class Employee{
	public int id;
	public String name;
	public double salary;

	Employee(int id, String name, double salary){
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
}