package com.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.medicare.model.Appointment;
import com.medicare.model.Doctor;
import com.medicare.model.Patient;
import com.medicare.model.Review;
import com.medicare.service.AppointmentService;
import com.medicare.service.DoctorService;
import com.medicare.service.PatientService;
import com.medicare.service.ReviewService;

import jakarta.servlet.http.HttpSession;

@Controller
public class PatientController {
	
	@Autowired
	DoctorService doctorService;
	
	@Autowired
	PatientService patientService;
	
	@Autowired
	AppointmentService appointmentService;
	
	@Autowired
	ReviewService reviewService;
	
	@GetMapping("/doctors")
	public String allDoctors(Model model) {
		List<Doctor> doctors = doctorService.getAllDocotrs();
		model.addAttribute("doctors", doctors);
		return "doctors";
	}
	
	@GetMapping("/doctor/{id}")
	public String doctorDetails(
			@PathVariable("id")long id,
			Model model
			) {
		Doctor doctor = doctorService.getDoctorById(id);
		model.addAttribute("doctor", doctor);
		return "doctor-details";
	}
	
	@PostMapping("/bookappointment")
	public String bookAppointment(
			@RequestParam("docId") long did,
			@RequestParam("appDate") String appDate,
			@RequestParam("purpose") String purpose,
			HttpSession session
			) {
		String email = (String)session.getAttribute("email");
		Patient patient = patientService.getPatientByEmail(email);
		
		Doctor doctor = doctorService.getDoctorById(did);
		Appointment appointment = new Appointment(appDate, purpose, doctor, patient);
		boolean response = appointmentService.addAppointment(appointment);
		if(response) {
			
		}
		return "redirect:/appointments";
	}
	
	@GetMapping("/appointments")
	public String allAppointments(HttpSession session, Model model) {
		String email = (String) session.getAttribute("email");
		Patient patient = patientService.getPatientByEmail(email);
		
		List<Appointment> appointments = appointmentService.getPatientAppointments(patient);
		model.addAttribute("appointments", appointments);
		return "appointments";
	}
	
	@GetMapping("/deleteAppointment/{id}")
	public String deleteAppointment(@PathVariable("id") long id) {
		appointmentService.deleteAppointment(id);
		return "redirect:/appointments";
	}
	
	@PostMapping("/addReview")
	public String addReview(
			@RequestParam("did") long did,
			@RequestParam("rating") int rating,
			@RequestParam("comment") String comment,
			HttpSession session
			) {
		Doctor doctor = doctorService.getDoctorById(did);
		String email = (String) session.getAttribute("email");
		Patient patient = patientService.getPatientByEmail(email);
		Review review = new Review(rating, comment, doctor, patient);
		reviewService.addReview(review);
		return "redirect:/doctor/"+did;
	}
	
}
