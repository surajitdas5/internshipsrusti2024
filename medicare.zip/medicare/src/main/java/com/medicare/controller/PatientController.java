package com.medicare.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.medicare.model.Doctor;
import com.medicare.service.DoctorService;

@Controller
public class PatientController {
	
	@Autowired
	DoctorService doctorService;
	
	@GetMapping("/doctors")
	public String allDoctors(Model model) {
		List<Doctor> doctors = doctorService.getAllDocotrs();
		model.addAttribute("doctors", doctors);
		return "doctors";
	}
	
	@GetMapping("/doctor/{id}")
	public String doctorDetails(
			@PathVariable("id")long id,
			Model model
			) {
		Doctor doctor = doctorService.getDoctorById(id);
		model.addAttribute("doctor", doctor);
		return "doctor-details";
	}
}
